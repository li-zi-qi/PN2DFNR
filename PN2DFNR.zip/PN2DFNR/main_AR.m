clear
clc
close all
% --------------------------------------------------------------------------
disp('load data');
load('AR_DAT.mat');
% -------------------------------------------------------------------------
Tr_DAT   =   double(NewTrain_DAT);
trls     =   trainlabels;
Tt_DAT   =   double(NewTest_DAT);
ttls     =   testlabels;

train_tol= size(Tr_DAT,2);
test_tol = size(Tt_DAT,2);

par.maxIter = 5;
% parameter setting
eigen_dim = 54;
par.disMetric     =   'spearman';
% par.disMetric     =   'seuclidean'; 
% par.disMetric     =   'minkowski'; 
% par.disMetric     =   'cosine'; 
par.lambda_1          =   0.1;
par.lambda_2          =   0.1;
par.mu                =   0.01;
par.k                 =   2;
par.extra_k           =   2;
% dim = 54, lambda_1 = 0.1, lambda_2 = 0.1, mu = 0.01, k = 2, k' = 2, acc = 87.12 
% dim = 120, lambda_1 = 0.1, lambda_2 = 0.01, mu = 0.09, k = 4, k' = 4, acc = 91.70
%--------------------------------------------------------------------------
%eigenface extracting
[disc_set,disc_value,Mean_Image]  =  Eigenface_f(Tr_DAT,eigen_dim);
tr_dat  =  disc_set'*Tr_DAT;
tt_dat  =  disc_set'*Tt_DAT;
tr_dat = normc(tr_dat);
tt_dat = normc(tt_dat);

pos = 0;
id = zeros(1, size(tt_dat, 2));
X = tr_dat;
[m, h] = size(X);
%----------------------------------------------------------------------
knnidx = knnsearch(Tr_DAT',Tt_DAT','K',max(par.k), 'Distance', par.disMetric);
for i = 1:size(par.k,2)
    for t = 1:par.k(i)
        Neigh = zeros(m,test_tol * par.k(i));
        if t == 1
            Neigh_Coef = tr_dat(:,knnidx(:,t));
            Neigh(:,1:test_tol * t) = tr_dat(:,knnidx(:,t));
            k_Labels = trls(:,knnidx(:,t))';
        else
            Neigh_Coef = Neigh_Coef + tr_dat(:,knnidx(:,t));
            Neigh(:,(test_tol * (t-1) + 1) : test_tol * t) = tr_dat(:,knnidx(:,t));
            k_Labels = [ k_Labels,trls(:,knnidx(:,t))'];
        end
    end
    Neigh_Coef = Neigh_Coef/par.k(i);
    
    all_knnidx = knnsearch(Tr_DAT', Tt_DAT', 'K', max(par.k) + max(par.extra_k), 'Distance', par.disMetric);
    extra_knnidx = all_knnidx(:, (max(par.k)+1) : ( max(par.k) + max(par.extra_k)));
    sameLabelCount = 0;  % 计数器，用于记录相同类标签的数量
    Extra_Neigh_Coef = zeros(size(tr_dat, 1), test_tol);
    Extra_Neigh = zeros(m,test_tol * par.extra_k(i));
    for n = 1:par.extra_k(i)
        if n == 1
            Extra_k_Labels = trls(:,extra_knnidx(:,n))';
        else
            Extra_k_Labels = [Extra_k_Labels,trls(:,extra_knnidx(:,n))'];
        end
    end
    Extra_k_Labels = double(Extra_k_Labels);
    k_Labels = double(k_Labels);
    C = zeros(size(Extra_k_Labels));
    for u = 1:size(Extra_k_Labels,1)
        C(u, :) = Extra_k_Labels(u, :) .* ismember(Extra_k_Labels(u, :), k_Labels(u, :));
    end
    for n = 1:par.extra_k(i)
        D=C(:,n);
        sameLabelCount = sameLabelCount + 1;
        H = tr_dat(:,extra_knnidx(:,n));
        for p = 1:length(D)
            if D(p) == 0  % 如果 D 的某一行元素为 0
                H(:, p) = 0;  % 将矩阵 E 对应的列设置为 0
            end
        end
        Extra_Neigh_Coef = Extra_Neigh_Coef + H;
        Extra_Neigh(:,(test_tol *(sameLabelCount - 1) + 1): test_tol *sameLabelCount) = H;
    end
    % 重新归一化 Neigh_Coef，如果需要
    Extra_Neigh_Coef = Extra_Neigh_Coef./par.extra_k(i);
    F1 = zeros(m, par.k(i) * test_tol);
    F2 = zeros(m, par.extra_k(i) * test_tol);
    
    for j = 1:size(par.lambda_1,2)
        for k = 1:size(par.lambda_2,2)
            for t = 1:size(par.mu,2)
                %computing the project matrix
                % 计算括号内的矩阵
                matrix_inside_inv = (1 + par.lambda_1(j) - par.lambda_2(k)) * (tr_dat' * tr_dat) + 0.5 * par.mu(t) * eye(h);
                
                % 计算矩阵的逆
                matrix_inv = pinv(matrix_inside_inv);
                
                % 计算最终结果
                Proj_M = matrix_inv;
                %------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                
                alpha = zeros(train_tol, test_tol);
                z = alpha;
                delta = alpha;
                %--------------------------------------------------------------------------
                
                iter = 0;
                while iter<par.maxIter
                    iter = iter + 1;
                    reshaped_F1 = reshape(F1, m, test_tol, par.k(i));
                    F1_summed = sum(reshaped_F1, 3);
                    reshaped_F2 = reshape(F2, m, test_tol, sameLabelCount);
                    F2_summed = sum(reshaped_F2, 3);
                    factor = X' * tt_dat - par.lambda_1(j) *  X' * F1_summed / par.k(i) + par.lambda_2(k) * X' * F2_summed / par.extra_k(i) + par.lambda_1(j) *  X' *  Neigh_Coef - par.lambda_2(k) * X' * Extra_Neigh_Coef + 0.5 * par.mu(t) * z + 0.5 * delta;
                    alpha = Proj_M * factor;
                    for ci = 1:par.k(i)
                        F1(:, (test_tol *(ci - 1) + 1): test_tol *ci) = Neigh(:,(test_tol *(ci - 1) + 1): test_tol *ci) - X * alpha;
                    end
                    for ci = 1:par.extra_k(i)
                        F2(:, (test_tol *(ci - 1) + 1): test_tol *ci) = Extra_Neigh(:,(test_tol *(ci - 1) + 1): test_tol *ci) - X * alpha;
                    end
                    z_temp = alpha-delta/par.mu(t);
                    z = max(0,z_temp);
                    delta = delta + par.mu(t) * (z - alpha);
                end
                %------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                %inference via sparse coding classifier with local information embbeding
                for indTest = 1:size(tt_dat,2)
                    id(indTest) = IDcheck_norm(tr_dat, alpha(:,indTest), tt_dat(:,indTest), trls);
                end
                cornum = sum(id==ttls);
                acc = cornum/length(ttls);
                
                fprintf('eigen_dim = %d, k = %f, lambda_1 = %f, lambda_2 = %f, mu = %f, acc = %.2f\n', eigen_dim, par.k(i), par.lambda_1(j), par.lambda_2(k), par.mu(t), acc*100);
            end
        end
    end
end
